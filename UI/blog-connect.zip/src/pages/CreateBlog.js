import BlogForm from "../components/blog/create/BlogForm";

const CreateBlog = (props) => {
  return <BlogForm method="post" />;
};

export default CreateBlog;
